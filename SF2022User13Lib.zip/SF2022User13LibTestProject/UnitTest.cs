﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using SF2022User13Lib;

namespace SF2022User13LibTestProject
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
