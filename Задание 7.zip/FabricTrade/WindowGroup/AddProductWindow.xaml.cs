﻿using FabricTrade.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FabricTrade.WindowGroup
{
    /// <summary>
    /// Логика взаимодействия для AddProductWindow.xaml
    /// </summary>
    public partial class AddProductWindow : Window
    {
        Entities entities;
        Product product;
        public AddProductWindow(Entities entities, Product product)
        {
            InitializeComponent();
            this.entities = entities;
            this.product = product;

            //заполнение ComboBox данными
            CategoryInput.ItemsSource = entities.ProductCategory.ToList();
            ManufacturerInput.ItemsSource = entities.Manufacturer.ToList();
            UnitInput.ItemsSource = entities.Unit.ToList();
            ProviderInput.ItemsSource = entities.Provider.ToList();

            //проверка на существующую запись в базе и в случае успеха
            //заполнение всех полей из базы
            if (product.ProductArticleNumber != null)
            {
                ArticleInput.Text = product.ProductArticleNumber;
                NameInput.Text = product.ProductName;
                DescriptionInput.Text = product.ProductDescription;
                CategoryInput.Text = product.ProductCategory1.ProductCategoryName;
                ManufacturerInput.Text = product.Manufacturer.ManufacturerName;
                CostInput.Text = product.ProductCost.ToString();
                DiscountAmountInput.Text = product.ProductDiscountAmount.ToString();
                QuantityInStockInput.Text = product.ProductQuantityInStock.ToString();
                UnitInput.Text = product.Unit.UnitName;
                ProviderInput.Text = product.Provider.ProviderName;
                MaxDiscountInput.Text = product.ProductMaxDiscount.ToString();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            //проверка на пустые элементы
            if(ArticleInput.Text == string.Empty ||
            NameInput.Text == string.Empty ||
            DescriptionInput.Text == string.Empty ||
            CategoryInput.SelectedValue == null ||
            ManufacturerInput.SelectedValue == null ||
            CostInput.Text == string.Empty ||
            DiscountAmountInput.Text == string.Empty ||
            QuantityInStockInput.Text == string.Empty ||
            UnitInput.SelectedValue == null ||
            ProviderInput.SelectedValue == null ||
            MaxDiscountInput.Text == string.Empty)
            {
                MessageBox.Show("Не все данные заполнены!");
                return;
            }

            //проверка на новую запись данных и сохранение её в базе
            if(product.ProductArticleNumber == null)
            {
                product.ProductArticleNumber = ArticleInput.Text;
                product.ProductName = NameInput.Text;
                product.ProductDescription = DescriptionInput.Text;
                product.ProductCategory = (int)CategoryInput.SelectedValue;
                product.ProductPhoto = "picture.png";
                product.ProductManufacturer = (int)ManufacturerInput.SelectedValue;
                product.ProductCost = Convert.ToInt32(CostInput.Text);
                product.ProductDiscountAmount = (byte)Convert.ToInt32(DiscountAmountInput.Text);
                product.ProductQuantityInStock = Convert.ToInt32(QuantityInStockInput.Text);
                product.ProductUnit = (int)UnitInput.SelectedValue;
                product.ProductProvider = (int)ProviderInput.SelectedValue;
                product.ProductMaxDiscount = Convert.ToInt32(MaxDiscountInput.Text);

                entities.Product.Add(product);
                entities.SaveChanges();
                this.DialogResult = true;
            }
            else
            {
                //сохранение изменений в базе
                product.ProductArticleNumber = ArticleInput.Text;
                product.ProductName = NameInput.Text;
                product.ProductDescription = DescriptionInput.Text;
                product.ProductCategory = (int)CategoryInput.SelectedValue;
                product.ProductPhoto = "picture.png";
                product.ProductManufacturer = (int)ManufacturerInput.SelectedValue;
                product.ProductCost = Convert.ToInt32(CostInput.Text);
                product.ProductDiscountAmount = (byte)Convert.ToInt32(DiscountAmountInput.Text);
                product.ProductQuantityInStock = Convert.ToInt32(QuantityInStockInput.Text);
                product.ProductUnit = (int)UnitInput.SelectedValue;
                product.ProductProvider = (int)ProviderInput.SelectedValue;
                product.ProductMaxDiscount = Convert.ToInt32(MaxDiscountInput.Text);

                entities.SaveChanges();
                this.DialogResult = true;
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void ProductCost_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }
    }
}
