﻿using System;
using FabricTrade.Database;
using FabricTrade.WindowGroup;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace FabricTrade
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Entities entities = new Entities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            if(LoginInput.Text == string.Empty ||
                PasswordInput.Password == string.Empty)
            {
                MessageBox.Show("Не все поля заполнены!");
                return;
            }

            //проверка введенной капчи пользователем
            if (CaptchaInput.Text != CaptchaOutput.Text)
            {
                MessageBox.Show("Капча введена неверно!" +
                    "\nБлокировка на 10 секунд!");
                Thread.Sleep(10000);
                return;
            }

            //проверка пароля и логина пользователя
            var checkUser = entities.User.FirstOrDefault(x => x.UserLogin == 
            LoginInput.Text &&  x.UserPassword == PasswordInput.Password);

            if (checkUser == null)
            {
                MessageBox.Show("Несоответствие логина и пароля!");

                RefreshCaptcha();
                CaptchaGrid.Visibility = Visibility.Visible;
                return;
            }            

            //разграничение пользователей по ролям
            if (checkUser.UserRole == 1)
            {
                ProductWindow productWindow = new ProductWindow
                    (entities, checkUser);
                productWindow.Show();
                this.Close();
                return;
            }
            if (checkUser.UserRole == 2)
            {
                ProductWindow productWindow = new ProductWindow
                    (entities, checkUser);
                productWindow.Show();
                this.Close();
                return;
            }
            if (checkUser.UserRole == 3)
            {
                ProductWindow productWindow = new ProductWindow
                    (entities, checkUser);
                productWindow.Show();
                this.Close();
                return;
            }
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e)
        {
            ProductWindow productWindow = new ProductWindow(entities, null);
            productWindow.Show();
            this.Close();
        }

        //метод обновления капчи
        private void RefreshCaptcha()
        {
            CaptchaOutput.Text = string.Empty;
            string text = "qwertyuiopasdfghjklzxcvbnm" +
                "QWERTYUIOPASDFGHJKLZXCVBNM" +
                "123456789";
            string captchaOutput = string.Empty;
            Random random = new Random();

            for(int i = 0; i < 4;  i++)
            {
                captchaOutput += text[random.Next(text.Length)].ToString();
            }

            CaptchaOutput.Text = captchaOutput;
        }

        private void RefrechCaptchaButton_Click(object sender, RoutedEventArgs e)
        {
            CaptchaOutput.Text = string.Empty;
            RefreshCaptcha();
        }
    }
}
